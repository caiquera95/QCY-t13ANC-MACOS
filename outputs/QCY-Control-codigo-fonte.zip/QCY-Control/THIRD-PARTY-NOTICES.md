# Código de terceiros

A interface de equalização em Sources/EqualizerView.swift e Sources/EqualizerGraph.swift adapta ideias e trechos de PresetGrid, AnimVector, EQGeo, EQCurveShape, EQGraph e EQPreset do projeto QCY MeloBuds para Mac.

Autor: Thiago Oliveira. Fonte: https://github.com/uxtigos/qcy-mac, commit 070189af36fe76f58c38606b79a9204a33e70e5c. Alterações: adaptação para bandas fixas/ganhos inteiros do T13 ANC, transporte RCSP existente, confirmação de ganhos, captura de curva inicial da sessão, acessibilidade e persistência local. Não incorpora o protocolo paramétrico HT-08 ou o visualizador de áudio.

MIT License

Copyright (c) 2026 Thiago Oliveira

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
